import { authApi, usuariosApi } from './usuariosService.js'
import { showErro, showOk } from './api.js'

// ── Roteamento por data-view ──────────────────────────────
function showView(name) {
  document.querySelectorAll('[data-view]').forEach(s => {
    s.hidden = s.getAttribute('data-view') !== name
  })
  clearMsgs()
  if (name === 'dashboard') carregarUsuarios()
}

function clearMsgs() {
  const e = document.getElementById('msgErro')
  const o = document.getElementById('msgOk')
  if (e) { e.textContent = ''; e.hidden = true }
  if (o) { o.textContent = ''; o.hidden = true }
}

document.addEventListener('click', e => {
  const t = e.target.closest('[data-goto]')
  if (t) { e.preventDefault(); showView(t.getAttribute('data-goto')) }
})

// Seletor de tipo no cadastro
document.querySelectorAll('.type-card').forEach(card => {
  card.addEventListener('click', () => {
    document.querySelectorAll('.type-card').forEach(c => c.classList.remove('selected'))
    card.classList.add('selected')
    const tipoEl = document.getElementById('tipo')
    if (tipoEl) tipoEl.value = card.getAttribute('data-tipo')
  })
})

showView('landing')

// ── Login ─────────────────────────────────────────────────
document.getElementById('formLogin')?.addEventListener('submit', async e => {
  e.preventDefault()
  const email    = document.getElementById('loginEmail').value.trim()
  const password = document.getElementById('loginSenha').value
  if (!email || !password) return showErro('Preencha email e senha.')
  try {
    const data = await authApi.login({ email, password })
    localStorage.setItem('token', data.token)
    localStorage.setItem('user', JSON.stringify(data.user))
    showOk('Login realizado!')
    showView('dashboard')
  } catch (err) { showErro(err.message) }
})

// ── Cadastro ──────────────────────────────────────────────
document.getElementById('formCadastro')?.addEventListener('submit', async e => {
  e.preventDefault()
  const name     = document.getElementById('cadNome').value.trim()
  const email    = document.getElementById('cadEmail').value.trim()
  const password = document.getElementById('cadSenha').value
  const tipo     = document.getElementById('tipo')?.value || 'comprador'

  if (!name || !email || !password) return showErro('Preencha todos os campos.')
  try {
    await authApi.cadastrar({ name, email, password, tipo })
    showOk('Cadastro realizado! Faça login.')
    showView('login')
  } catch (err) { showErro(err.message) }
})

// ── Logout ────────────────────────────────────────────────
document.getElementById('btnLogout')?.addEventListener('click', async () => {
  try { await authApi.logout() } catch (_) {}
  localStorage.removeItem('token')
  localStorage.removeItem('user')
  showView('landing')
})

// ── CRUD Usuários (dashboard) ─────────────────────────────
const lista    = document.getElementById('listaUsuarios')
const formUser = document.getElementById('formUsuario')
const inpNome  = document.getElementById('userNome')
const inpEmail = document.getElementById('userEmail')
const inpId    = document.getElementById('userId')
const btnSalvar = formUser?.querySelector('button[type="submit"]')

let editId = null

function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g,
    c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]))
}

// Limpa o formulário e volta ao modo "novo"
function resetForm() {
  formUser?.reset()
  if (inpId) inpId.value = ''
  editId = null
  if (btnSalvar) btnSalvar.textContent = 'Salvar'
}

// ── READ ALL ──────────────────────────────────────────────
async function carregarUsuarios() {
  if (!lista) return
  lista.innerHTML = '<tr><td colspan="3" class="tbl-loading">Carregando...</td></tr>'
  try {
    const dados = await usuariosApi.listar()
    const arr = Array.isArray(dados) ? dados : (dados?.data ?? [])
    if (!arr.length) {
      lista.innerHTML = '<tr><td colspan="3" class="tbl-empty">Nenhum usuário cadastrado.</td></tr>'
      return
    }
    lista.innerHTML = arr.map(u => `
      <tr>
        <td>${escapeHtml(u.name)}</td>
        <td>${escapeHtml(u.email)}</td>
        <td class="tbl-actions">
          <button class="btn btn-outline btn-sm" data-edit="${u.id}">Editar</button>
          <button class="btn btn-red btn-sm"     data-del="${u.id}">Excluir</button>
        </td>
      </tr>`).join('')
  } catch (err) {
    lista.innerHTML = '<tr><td colspan="3" class="tbl-empty">Erro ao carregar.</td></tr>'
    showErro(err.message)
  }
}

// ── CREATE + UPDATE ───────────────────────────────────────
formUser?.addEventListener('submit', async e => {
  e.preventDefault()
  const name  = inpNome?.value.trim()
  const email = inpEmail?.value.trim()
  if (!name || !email) return showErro('Preencha nome e email.')

  try {
    if (editId) {
      // UPDATE — atualiza nome e email via PUT /users/:id
      await usuariosApi.atualizar(editId, { name, email })
      showOk('Usuário atualizado com sucesso!')
    } else {
      // CREATE — usa /auth/register com senha temporária aleatória
      const senhaTemp = 'Temp' + Math.random().toString(36).slice(-6) + '1!'
      await authApi.cadastrar({ name, email, password: senhaTemp, tipo: 'comprador' })
      showOk('Usuário criado! Senha temporária: ' + senhaTemp)
    }
    resetForm()
    carregarUsuarios()
  } catch (err) { showErro(err.message) }
})

// ── READ ONE (editar) + DELETE ────────────────────────────
lista?.addEventListener('click', async e => {
  const btn = e.target.closest('button[data-edit], button[data-del]')
  if (!btn) return

  if (btn.hasAttribute('data-edit')) {
    // READ ONE — busca e preenche o formulário
    const id = btn.getAttribute('data-edit')
    try {
      const u    = await usuariosApi.buscar(id)
      const item = u?.data ?? u
      editId         = item.id
      if (inpId)    inpId.value    = item.id
      if (inpNome)  inpNome.value  = item.name  ?? ''
      if (inpEmail) inpEmail.value = item.email ?? ''
      if (btnSalvar) btnSalvar.textContent = 'Atualizar'
      formUser?.scrollIntoView({ behavior: 'smooth', block: 'start' })
      inpNome?.focus()
    } catch (err) { showErro(err.message) }

  } else {
    // DELETE
    const id = btn.getAttribute('data-del')
    if (!confirm('Tem certeza que deseja excluir este usuário?')) return
    try {
      await usuariosApi.remover(id)
      showOk('Usuário removido com sucesso!')
      if (editId == id) resetForm()
      carregarUsuarios()
    } catch (err) { showErro(err.message) }
  }
})