import { request } from './api.js'

// ── Auth ──────────────────────────────────────────────────
export const authApi = {
  login:     (body) => request('/auth/login',    { method: 'POST', body: JSON.stringify(body) }),
  cadastrar: (body) => request('/auth/register', { method: 'POST', body: JSON.stringify(body) }),
  logout:    ()     => request('/auth/logout',   { method: 'POST' }),
}

// ── CRUD Usuários (para o dashboard do admin) ─────────────
export const usuariosApi = {
  listar:    ()         => request('/users'),
  buscar:    (id)       => request(`/users/${id}`),
  atualizar: (id, body) => request(`/users/${id}`, { method: 'PUT',    body: JSON.stringify(body) }),
  remover:   (id)       => request(`/users/${id}`, { method: 'DELETE' }),
}